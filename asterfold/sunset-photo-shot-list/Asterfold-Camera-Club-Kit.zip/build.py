from pathlib import Path
from io import BytesIO
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

root = Path(__file__).parent
for face, file in [('Desk','DejaVuSans.ttf'),('DeskBold','DejaVuSans-Bold.ttf'),('Display','DejaVuSerif-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(face, '/usr/share/fonts/truetype/dejavu/'+file))
name = root/'Asterfold-Viewpoint-Field-Card.pdf'
url = 'https://apps.apple.com/us/app/asterfold-sunset-planner/id6806044403'
c = canvas.Canvas(str(name), pagesize=letter)
c.setTitle('Move the camera, move the overlap | Field card')
c.setAuthor('Honest Little Apps')
ink, muted, accent, pale = map(HexColor, ['#192934','#415761','#915128','#EAEDE8'])
def text(x,y,s,sz=11,face='Desk',color=ink):
    c.setFillColor(color); c.setFont(face,sz); c.drawString(x,y,s)
def rule(x,y,w,col=muted):
    c.setStrokeColor(col); c.setLineWidth(.65); c.line(x,y,x+w,y)
def frame(x,y,w,h,near_x):
    c.setFillColor(pale); c.roundRect(x,y,w,h,6,fill=1,stroke=0)
    c.setStrokeColor(muted); c.setLineWidth(1.5)
    c.line(x+8,y+h*.35,x+w-8,y+h*.35)
    c.setFillColor(accent); c.circle(x+w*.58,y+h*.52,6.5,fill=1,stroke=0)
    c.setStrokeColor(ink); c.setLineWidth(3); c.line(x+near_x*w,y+7,x+near_x*w,y+h*.73)
    c.setLineWidth(1.4); c.line(x+near_x*w,y+h*.53,x+near_x*w+8,y+h*.68)
def act(y,n,title,lines):
    text(48,y,n,12,'DeskBold',accent); text(83,y,title,14,'DeskBold')
    for i,line in enumerate(lines):text(83,y-18-i*14,line,10)
def answer(y,prompt):
    text(48,y,prompt,10,'DeskBold'); rule(48,y-22,516)
text(48,749,'HONEST LITTLE APPS  /  CAMERA CLUB FIELD CARD',9,'DeskBold',accent)
text(48,699,'Move the camera,',36,'Display')
text(48,654,'move the overlap',36,'Display')
text(48,624,'A ten-minute photo exercise for two people, a phone and two fixed objects.',11)
text(48,606,'Try it indoors with a pencil and a spot on a far wall, or use two outdoor landmarks.',10)
frame(48,492,243,90,.58);frame(321,492,243,90,.30)
text(48,476,'A   The near object overlaps the far mark.',9,'DeskBold')
text(321,476,'B   The near object clears the far mark.',9,'DeskBold')
text(48,457,'Example frames. The dot marks a distant feature in this exercise.',9,'Desk',muted)
rule(48,439,516)
act(412,'01','Line up two features.',[
  'Choose a near vertical edge and a distant fixed mark. From one spot, frame them',
  'so that the edge covers the mark. Use one zoom setting. Take photo A.'])
act(351,'02','Predict, step, compare.',[
  'Predict which side of the edge will reveal the mark. Take one small sideways step',
  'on level ground. Keep the same zoom, re-centre the far mark, then take photo B.'])
act(290,'03','Change the crop, keep the spot.',[
  'Stay at B. Crop photo B more tightly around the mark. Compare the overlap in',
  'the crop with photo B, then compare A with B. Which change moved the edge?'])
answer(230,'Our prediction and what actually happened')
answer(179,'Which frame would you keep, and what distracts from the subject in the other?')
rule(48,122,516)
text(48,102,'For a sunset shoot',11,'DeskBold')
text(48,84,'Asterfold can show dates when sunset fits a chosen lens frame.',9)
text(48,70,'Its free tier supports two viewpoints. Terrain and buildings are outside',9)
text(48,56,'the flat-horizon model. Check the actual view when choosing your spot.',9)
text(48,32,'Permission to print and share this original card for club and classroom use.',8,'Desk',muted)
qr=QrCodeWidget(url,barWidth=68,barHeight=68,barBorder=4)
drawing=Drawing(68,68);drawing.add(qr);renderPDF.draw(drawing,c,499,43)
text(504,37,"App Store",8,"DeskBold")
c.linkURL(url,(494,34,571,114),relative=0)
c.showPage();c.save()
